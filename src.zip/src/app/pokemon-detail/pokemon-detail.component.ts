import { Component, OnInit } from '@angular/core';
import { Pokemon } from '../pokemon';

@Component({
  selector: 'app-pokemon-detail',
  templateUrl: './pokemon-detail.component.html',
  styleUrls: ['./pokemon-detail.component.css']
})
export class PokemonDetailComponent implements OnInit {
  imageX : number = 0
  imageY : number = 0
  pokemon: Pokemon;

  constructor(
  ) {

  }

  ngOnInit() {
  }

  onPokemonSelect(selectedPokemon : Pokemon){
    this.pokemon = selectedPokemon;
  }

}
