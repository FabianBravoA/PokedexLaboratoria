export class Pokemon {
    constructor(
        public name : string,
        public description : string,
        public type : string
    ){}
}
