import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Pokemon } from '../pokemon';

@Component({
  selector: 'app-pokemon-list-item',
  templateUrl: './pokemon-list-item.component.html',
  styleUrls: ['./pokemon-list-item.component.css']
})
export class PokemonListItemComponent implements OnInit {
  @Input() public pokemon:any = {};
  @Output() onPokemonSelected = new EventEmitter<string>();

  constructor() { }

  ngOnInit() {
  }

  onPokemonClick(){
    this.onPokemonSelected.emit(this.pokemon.id);
  }

}
